package com.osamload.app

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var urlInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        handleSharedText(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleSharedText(intent)
    }

    private fun buildScreen() {
        val bg = 0xFF10121B.toInt()
        val panel = 0xFF1D2030.toInt()
        val accent = 0xFF8B7CFF.toInt()

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 38, 24, 24)
            setBackgroundColor(bg)
        }

        val brand = TextView(this).apply {
            text = "⬇  OsamLoad"
            textSize = 30f
            setTextColor(-1)
            gravity = Gravity.CENTER_VERTICAL
        }
        page.addView(brand, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Your media, organized."
            textSize = 14f
            setTextColor(0xFFB8B9C8.toInt())
            setPadding(2, 8, 2, 28)
        }
        page.addView(subtitle, matchWrap())

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(panel)
        }
        page.addView(card, matchWrap())

        card.addView(TextView(this).apply {
            text = "Paste a video or media link"
            textSize = 17f
            setTextColor(-1)
        }, matchWrap())

        urlInput = EditText(this).apply {
            hint = "https://…"
            textSize = 14f
            setSingleLine(true)
            setTextColor(-1)
            setHintTextColor(0xFF85879A.toInt())
            setPadding(12, 12, 12, 12)
            setBackgroundColor(0xFF292D40.toInt())
        }
        val inputParams = LinearLayout.LayoutParams(-1, 54)
        inputParams.topMargin = 14
        card.addView(urlInput, inputParams)

        val download = Button(this).apply {
            text = "Download direct media"
            setTextColor(-1)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent))
            setOnClickListener { startDownload() }
        }
        val buttonParams = LinearLayout.LayoutParams(-1, 54)
        buttonParams.topMargin = 14
        card.addView(download, buttonParams)

        status = TextView(this).apply {
            text = "Paste a direct downloadable media URL to save it to your Downloads folder."
            textSize = 13f
            setTextColor(0xFFB8B9C8.toInt())
            setPadding(2, 18, 2, 4)
        }
        page.addView(status, matchWrap())

        val platforms = TextView(this).apply {
            text = "\nSUPPORTED LINK RECOGNITION\n\n▶  YouTube     ●  Facebook\n◎  Instagram     ♪  TikTok"
            textSize = 15f
            setTextColor(-1)
            setPadding(4, 24, 4, 10)
        }
        page.addView(platforms, matchWrap())

        val note = TextView(this).apply {
            text = "Social-platform links are recognized, but this starter build does not extract protected streams or bypass platform restrictions. Use each platform’s official download/offline feature where available. Direct media URLs can be downloaded below."
            textSize = 12f
            setTextColor(0xFF9295A8.toInt())
            setPadding(4, 16, 4, 0)
        }
        page.addView(note, matchWrap())

        val scroll = ScrollView(this)
        scroll.addView(page)
        setContentView(scroll)
    }

    private fun startDownload() {
        val raw = urlInput.text.toString().trim()
        val uri = runCatching { Uri.parse(raw) }.getOrNull()
        if (uri == null || (uri.scheme != "https" && uri.scheme != "http") || uri.host.isNullOrBlank()) {
            status.text = "Please enter a valid http or https URL."
            return
        }

        val host = uri.host!!.lowercase()
        val platform = when {
            host.contains("youtube.com") || host == "youtu.be" -> "YouTube"
            host.contains("facebook.com") || host == "fb.watch" -> "Facebook"
            host.contains("instagram.com") -> "Instagram"
            host.contains("tiktok.com") -> "TikTok"
            else -> "direct media"
        }

        if (platform != "direct media") {
            status.text = "$platform link detected. This build cannot extract platform-hosted streams. Use the platform's official download/offline options, or paste a direct media file URL."
            return
        }

        try {
            val request = DownloadManager.Request(uri)
                .setTitle("OsamLoad download")
                .setDescription("Downloading to your Downloads folder")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "OsamLoad_${System.currentTimeMillis()}")
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            status.text = "Download started. Check your notification or Downloads folder."
        } catch (e: Exception) {
            status.text = "Could not start download: ${e.localizedMessage ?: "unknown error"}"
        }
    }

    private fun handleSharedText(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val shared = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (!shared.isNullOrBlank() && ::urlInput.isInitialized) urlInput.setText(shared)
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
