# OsamLoad

A minimal Android starter project for organizing media links and downloading **direct, publicly downloadable media-file URLs**.

## Build APK on GitHub

1. Create a new GitHub repository named `OsamLoad`.
2. Upload the contents of this ZIP to the repository root (not the ZIP file itself).
3. Open **Actions** → **Build OsamLoad APK**.
4. Select **Run workflow** (or push to `main`).
5. When the workflow finishes, open its run and download the `OsamLoad-debug-apk` artifact.
6. Extract the artifact ZIP to get `app-debug.apk`.

## Current functionality

- Dark, simple OsamLoad interface.
- Accepts shared text links from Android's Share menu.
- Recognizes YouTube, Facebook, Instagram and TikTok URLs.
- Downloads direct HTTP/HTTPS media-file URLs using Android DownloadManager.
- Saves completed files in the device Downloads folder.

## Important limitation

This starter project does **not** extract video streams from YouTube, Facebook, Instagram or TikTok pages, bypass DRM, evade login/access controls, or circumvent platform restrictions. Platform URLs are recognized and explained, but need to be downloaded through official platform features or an authorized integration. A normal webpage URL is not a direct media-file URL.

## Technical notes

- Native Android app, Kotlin, Android SDK 35.
- Minimum Android version: Android 6.0 (API 23).
- GitHub Actions builds a debug APK. A release APK should be signed with your own securely stored signing key before distribution.
